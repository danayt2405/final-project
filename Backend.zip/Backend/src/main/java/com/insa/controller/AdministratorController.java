package com.insa.controller;

import com.insa.entity.User;
import com.insa.entity.ComplaintType;
import com.insa.repository.UserRepository;
import com.insa.repository.ComplaintTypeRepository;

import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/administrator")
public class AdministratorController {

    private final UserRepository userRepository;
    private final ComplaintTypeRepository complaintTypeRepository;
    private final PasswordEncoder passwordEncoder;

    public AdministratorController(UserRepository userRepository,
                                   ComplaintTypeRepository complaintTypeRepository,
                                   PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.complaintTypeRepository = complaintTypeRepository;
        this.passwordEncoder = passwordEncoder;
    }

    // =========================
    // GET ALL FOCAL PERSONS
    // =========================
    @GetMapping("/admins")
    public List<User> getAllAdmins() {
        return userRepository.findByRole(User.Role.admin);
    }

    // =========================
    // CREATE FOCAL PERSON
    // =========================
    @PostMapping("/admins")
    public User createAdmin(@RequestBody User user) {

        user.setRole(User.Role.admin);
        user.setPasswordHash(passwordEncoder.encode(user.getPasswordHash()));
        user.setActive(true);

        return userRepository.save(user);
    }

    // =========================
    // DELETE FOCAL PERSON
    // =========================
    @DeleteMapping("/admins/{id}")
    public void deleteAdmin(@PathVariable Long id) {

        User user = userRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("User not found"));

        if (user.getRole() != User.Role.admin) {
            throw new RuntimeException("Only focal person accounts can be deleted");
        }

        userRepository.delete(user);
    }

    // =========================
    // GET ALL DEPARTMENTS
    // =========================
    @GetMapping("/departments")
    public List<ComplaintType> getDepartments() {
        return complaintTypeRepository.findAll();
    }

    // =========================
    // ADD DEPARTMENT
    // =========================
    @PostMapping("/departments")
    public ComplaintType addDepartment(@RequestBody ComplaintType type) {
        return complaintTypeRepository.save(type);
    }

    // =========================
    // DELETE DEPARTMENT
    // =========================
    @DeleteMapping("/departments/{id}")
    public void deleteDepartment(@PathVariable Long id) {
        complaintTypeRepository.deleteById(id);
    }
}